document.getElementById("shuffleBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "shuffle" });
});
