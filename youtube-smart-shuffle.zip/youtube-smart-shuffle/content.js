function shuffleOnSongEnd() {
    console.log("YouTube Smart Shuffle is running...");

    // Detect when the video ends
    let video = document.querySelector("video");
    if (video) {
        video.addEventListener("ended", () => {
            console.log("Song ended! Picking a new random song...");
            chrome.runtime.sendMessage({ action: "shuffle" });
        });
    } else {
        console.log("No video found!");
    }
}

// Run function when page loads
shuffleOnSongEnd();
