﻿chrome.runtime.onInstalled.addListener(() => {
    console.log("YouTube Smart Shuffle Extension Installed");
});

async function getYouTubeHistory() {
    let historyItems = await chrome.history.search({ text: "youtube", maxResults: 50 });

    // Filter to only include individual videos (not playlists)
    let songs = historyItems.filter(item => 
        item.url.includes("watch?v=") && !item.url.includes("&list=")
    );

    return songs.map(item => item.url);
}

async function playNextSong() {
    let songs = await getYouTubeHistory();
    if (songs.length > 0) {
        let randomSong = songs[Math.floor(Math.random() * songs.length)];
        chrome.tabs.update({ url: randomSong }); // Open new song
    } else {
        console.log("No songs found in history!");
    }
}

chrome.action.onClicked.addListener(() => {
    playNextSong();
});

chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "shuffle") {
        playNextSong();
    }
});
